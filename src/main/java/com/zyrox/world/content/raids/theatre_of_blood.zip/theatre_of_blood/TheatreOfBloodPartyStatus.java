package com.solace.world.content.raids.theatre_of_blood;

/**
 * Created by Jonny on 7/8/2019
 **/
public enum TheatreOfBloodPartyStatus {

    COLLECTING_MEMBERS,
    STARTED_MEMBERS_JOINING,
    STARTED_NO_MORE_JOINING;

}
