package com.solace.world.content.raids.theatre_of_blood;

/**
 * Created by Jonny on 7/2/2019
 **/
public class TheatreOfBloodConstants {

    public static boolean RELEASED = false;

}
