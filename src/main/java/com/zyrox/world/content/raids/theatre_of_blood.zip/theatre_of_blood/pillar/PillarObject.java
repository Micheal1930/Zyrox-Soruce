package com.solace.world.content.raids.theatre_of_blood.pillar;

import com.solace.model.GameObject;
import com.solace.model.Position;
import com.solace.world.content.CustomObjects;

/**
 * Created by Jonny on 7/8/2019
 **/
public class PillarObject extends GameObject {

    public PillarObject(int id, Position position, int type, int face) {
        super(id, position, type, face);

        CustomObjects.spawnGlobalObject(this);
    }
}
