package com.solace.world.content.raids.theatre_of_blood;

import java.util.HashMap;

/**
 * Created by Jonny on 7/8/2019
 **/
public class TheatreOfBloodGlobal {

    private static HashMap<Integer, TheatreOfBlood> THEATRES = new HashMap<Integer, TheatreOfBlood>();

}
